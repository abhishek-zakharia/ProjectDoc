-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: tff-saas.cm9usufjprqr.us-east-2.rds.amazonaws.com    Database: the_final_final_staging
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `deliveries`
--

DROP TABLE IF EXISTS `deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deliveries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_id` int NOT NULL,
  `pickup_location` varchar(255) NOT NULL,
  `destination_location` varchar(255) NOT NULL,
  `pikup_point` geometry NOT NULL,
  `destination_point` geometry NOT NULL,
  `expected_delivery_time` datetime NOT NULL,
  `item_description` varchar(255) DEFAULT NULL,
  `driver_notes` varchar(255) DEFAULT NULL,
  `item_packaged` varchar(255) DEFAULT NULL,
  `destination_type` varchar(255) NOT NULL,
  `destination_stair_info` varchar(255) DEFAULT NULL,
  `destination_elvetor_info` varchar(255) DEFAULT NULL,
  `destination_coi_info` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `driver_id` int DEFAULT NULL,
  `createdBy` int NOT NULL,
  `user_id` int NOT NULL,
  `store_name` varchar(255) DEFAULT NULL,
  `live_location` geometry DEFAULT NULL,
  `room_id` varchar(255) DEFAULT NULL,
  `total_price` float DEFAULT NULL,
  `item_heavy` varchar(255) DEFAULT NULL,
  `total_info` json DEFAULT NULL,
  `pickup_type` varchar(255) DEFAULT NULL,
  `expected_drop_off_delivery_time` datetime DEFAULT NULL,
  `value_of_item` varchar(255) DEFAULT NULL,
  `assembly` tinyint(1) DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `pickup_contact` varchar(255) DEFAULT NULL,
  `dropoff_contact` varchar(255) DEFAULT NULL,
  `pickup_contact_phone_number` varchar(255) DEFAULT NULL,
  `dropoff_contact_phone_number` varchar(255) DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `discount_type` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=369 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-25 14:19:11
